console.log('hello');
alert('Django')